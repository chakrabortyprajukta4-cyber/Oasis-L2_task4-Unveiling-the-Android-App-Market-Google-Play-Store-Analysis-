# google_play_analysis.py
"""
Google Play Store Analysis
Requirements:
pip install pandas numpy matplotlib seaborn plotly nltk vaderSentiment
Place googleplaystore.csv and googleplaystore_user_reviews.csv in the same folder.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# 1. Load Data (Using relative paths to prevent unicodeescape errors)
apps = pd.read_csv("googleplaystore.csv")
reviews = pd.read_csv("googleplaystore_user_reviews.csv")

# 2. Clean Apps Data
apps = apps.drop_duplicates().dropna(subset=["App"])

# Clean Installs column
apps["Installs"] = apps["Installs"].astype(str).str.replace(r"[+,]", "", regex=True)
apps["Installs"] = pd.to_numeric(apps["Installs"], errors="coerce")

# Clean Price column
apps["Price"] = apps["Price"].astype(str).str.replace("$", "", regex=False)
apps["Price"] = pd.to_numeric(apps["Price"], errors="coerce").fillna(0)

# Clean Numeric Columns
apps["Rating"] = pd.to_numeric(apps["Rating"], errors="coerce")
apps["Reviews"] = pd.to_numeric(apps["Reviews"], errors="coerce")

# Clean Size column
apps["Size"] = (
    apps["Size"]
    .astype(str)
    .str.replace("M", "", regex=False)
    .str.replace("k", "", regex=False)
)
apps["Size"] = pd.to_numeric(apps["Size"], errors="coerce")

# Drop rows missing crucial values
apps = apps.dropna(subset=["Rating", "Installs"])

# 3. Data Visualizations
# Bar chart: Top 15 Categories
plt.figure(figsize=(10, 5))
apps["Category"].value_counts().head(15).plot(kind="bar")
plt.title("Top 15 App Categories")
plt.xlabel("Category")
plt.ylabel("Number of Apps")
plt.tight_layout()
plt.show()

# Histogram: Distribution of Ratings
plt.figure()
sns.histplot(apps["Rating"], bins=20, kde=True)
plt.title("Distribution of App Ratings")
plt.show()

# Scatter Plot: Size vs Installs
plt.figure()
sns.scatterplot(data=apps, x="Size", y="Installs", alpha=0.5)
plt.title("App Size vs Installs")
plt.show()

# Pie Chart: Free vs Paid
plt.figure()
apps["Type"].value_counts().plot(kind="pie", autopct="%1.1f%%", startangle=90)
plt.title("App Type Distribution (Free vs Paid)")
plt.ylabel("")
plt.show()

# Histogram: Distribution of Paid App Prices
paid = apps[apps["Type"] == "Paid"]
if not paid.empty:
    plt.figure()
    sns.histplot(paid["Price"], bins=20)
    plt.title("Distribution of Paid App Prices")
    plt.show()

# 4. Revenue Calculation
apps["EstimatedRevenue"] = apps["Price"] * apps["Installs"]
print("\n--- Estimated Revenue by Category (Top 5) ---")
print(apps.groupby("Category")["EstimatedRevenue"].sum().sort_values(ascending=False).head())

# 5. Sentiment Analysis
an = SentimentIntensityAnalyzer()
reviews = reviews.dropna(subset=["Translated_Review"])

reviews["compound"] = reviews["Translated_Review"].apply(
    lambda x: an.polarity_scores(str(x))["compound"]
)
reviews["Sentiment"] = reviews["compound"].apply(
    lambda c: "Positive" if c > 0.05 else ("Negative" if c < -0.05 else "Neutral")
)

# Merge Sentiment with App Categories
merged = reviews.merge(apps[["App", "Category"]], on="App", how="left")
print("\n--- Sentiment Crosstab by Category ---")
print(pd.crosstab(merged["Category"], merged["Sentiment"]))

# Interactive Plotly Chart
fig = px.scatter(
    apps,
    x="Rating",
    y="Installs",
    color="Category",
    hover_name="App",
    title="Interactive Rating vs Installs by Category",
)
fig.show()

# Print Key Insights
print("\n--- Key Insights ---")
print("Top insight: Focus on high-rated categories with lower competition.")
print("Use freemium pricing where possible.")
print("Monitor review sentiment after launch.")

# 6. Save Processed Datasets
apps.to_csv("cleaned_googleplaystore.csv", index=False)
reviews.to_csv("reviews_with_sentiment.csv", index=False)
print("\nFiles successfully cleaned and saved!")